# Завдання 3: Full-Stack Додаток (Frontend + Backend + DB)

Це повноцінний 3-компонентний додаток, запущений з Docker Compose.

- **Frontend:** Nginx-сервер, який віддає `index.html` та проксіює запити до Backend.
- **Backend:** Python (Flask) сервер, який спілкується з базою даних.
- **Database:** PostgreSQL база даних.

## 🚀 Як запустити

1. Переконайтеся, що Docker Desktop запущений.
2. Виконайте команду: `docker-compose up --build`
3. Відкрийте у браузері: `http://localhost:8080`

## 🩺 Перевірка стану (Healthchecks)

- **Frontend:** `http://localhost:8080`
- **Backend:** `http://localhost:5001/health` (недоступний ззовні, лише всередині Docker)
- **Database:** Перевіряється автоматично через `pg_isready`